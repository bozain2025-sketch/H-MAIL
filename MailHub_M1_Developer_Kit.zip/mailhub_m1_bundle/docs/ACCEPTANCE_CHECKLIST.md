# Acceptance and QA checklist

Mark every item with ✅ passed, ❌ failed, or ⏳ not run. Attach command output, screenshots, or real test evidence in the repository. Do not use a global "done" claim without completing the applicable phase checks.

## A. App shell / Apple Silicon

- [ ] Rust, Node, pnpm, Xcode tools versions recorded on Mac.
- [ ] `uname -m` reported `arm64` on target M1+ Mac.
- [ ] Tauri 2 launches and its macOS titlebar/traffic lights do not overlap content.
- [ ] `aarch64-apple-darwin` `.app` built and architecture inspected with `file` (release phase).
- [ ] `.dmg` built and opened successfully on target Mac (release phase).
- [ ] No unsigned/notarized claims without actual validation and credentials.

## B. UI visual/interaction

- [ ] Three-pane app shell and adjustable/collapsible panes.
- [ ] 1000+ synthetic message rows do not create 1000+ mounted DOM rows.
- [ ] At least 100 synthetic account entries searchable and grouped.
- [ ] Light/dark and English/Arabic tested at 1440×900 and 1280×800.
- [ ] Mac traffic light area, vertical scrolling, reader content, and long subjects visually inspected.
- [ ] Visible keyboard focus, screen reader labels and WCAG AA text contrast basics.
- [ ] ⌘K, ⌘N, ⌘R, ⌘, are functional (or explicitly disabled and documented).
- [ ] Reduced-motion is respected; no essential controls accessible only on hover.
- [ ] Any loading/empty/error/offline state gives a real next action.
- [ ] All mock data are clearly identified as sample, not actual mailbox contents.

## C. Credential safety and provider features

- [ ] Secrets/tokens are stored in Keychain, not SQLite, JS storage or logs.
- [ ] OAuth PKCE/state verification and revoked-token recovery covered by tests.
- [ ] Generic IMAP with TLS lists folders and downloads message headers incrementally.
- [ ] Generic SMTP sends a test email from the selected correct account.
- [ ] Gmail API authorization + synchronization + send tested if OAuth config available.
- [ ] Microsoft Graph authorization + delta synchronization + send tested if OAuth config available.
- [ ] Missing OAuth config yields a helpful setup/error screen, no simulated success.
- [ ] Removing an account clears local credentials but does not delete provider mailbox.

## D. Mail correctness

- [ ] Unified inbox retains account provenance and provider IDs.
- [ ] Inbox excludes sent/drafts unless explicitly selected.
- [ ] Reply picks original account, From is shown, and multi-account switching is safe.
- [ ] MIME headers, plain text, HTML multipart, encoded subjects and Unicode tested.
- [ ] Unsafe HTML script/event/URL cannot execute, reader has no privileged IPC.
- [ ] Remote images blocked by default and permitted only with explicit action.
- [ ] Attachment filenames/path traversal sanitized; opening requires user action.
- [ ] Search results correctly describe local indexing coverage.
- [ ] Bulk delete/archive supports provider semantics and safe confirmation/undo.

## E. Sync correctness and resilience

- [ ] Global and per-provider concurrency caps enforced; limit documented.
- [ ] Retry with backoff/jitter honors rate limits and Retry-After.
- [ ] Gmail history cursor recovery implemented and tested (if supported).
- [ ] Microsoft Graph per-folder delta recovery implemented and tested (if supported).
- [ ] IMAP UIDVALIDITY changes handled without corrupting local state.
- [ ] Loss of connectivity, wake from sleep and cancellation do not lose checkpoint consistency.
- [ ] Per-account failure does not freeze other accounts or entire UI.
- [ ] Repeated sends after timeout cannot silently duplicate outgoing mail.

## F. Storage / release hygiene

- [ ] SQLite migrations reversible/controlled and backed by integration tests.
- [ ] Local drafts recover after restart.
- [ ] WAL/FTS indexes checked and search tested with Arabic/English synthetic cases.
- [ ] Cache size, cleanup, and on-demand attachments function as documented.
- [ ] Tests and typecheck/lint are green; release artifacts listed with checksum.
- [ ] Actual release size and app process memory measured; no guessed benchmarks reported as results.
- [ ] `README.md` includes requirements, setup, OAuth registration, privacy, troubleshooting and known limitations.
- [ ] `docs/ARCHITECTURE_DECISIONS.md` records all deviations and incomplete features.

## Suggested automated test commands (adapt to repository scripts)

```bash
pnpm lint
pnpm typecheck
pnpm test
cargo fmt --manifest-path src-tauri/Cargo.toml --check
cargo clippy --manifest-path src-tauri/Cargo.toml --all-targets -- -D warnings
cargo test --manifest-path src-tauri/Cargo.toml
python3 skills/macos-mail-ui/scripts/check_contrast.py
```

## Reporting template

| Check | Status | Observed evidence | Follow-up |
|---|---|---|---|
| | ⏳ | | |
